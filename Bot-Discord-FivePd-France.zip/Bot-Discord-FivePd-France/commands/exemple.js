exports.run = (client, message, args) => {
  var Discord = require("discord.js");
    //VOTRE CODE ICI
};